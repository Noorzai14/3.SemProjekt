﻿namespace BarberAkji.Models.Enums;

public enum ServiceType
{
    Haircut = 30,
    BeardTrim = 15,
    HairAndBeard = 45
}

